import { ComponentFixture, TestBed } from '@angular/core/testing';
import { ActivatedRoute, convertToParamMap, provideRouter } from '@angular/router';
import { of } from 'rxjs';
import { TransactionFormComponent } from './transaction-form.component';

const STORAGE_KEY = 'expense-tracker-transactions-v1';

function createComponent(id?: string): ComponentFixture<TransactionFormComponent> {
  TestBed.resetTestingModule();

  const routeStub = {
    paramMap: of(convertToParamMap(id ? { id } : {})),
    snapshot: { paramMap: convertToParamMap(id ? { id } : {}) }
  };

  TestBed.configureTestingModule({
    imports: [TransactionFormComponent],
    providers: [
      provideRouter([]),
      { provide: ActivatedRoute, useValue: routeStub }
    ]
  });

  const fixture = TestBed.createComponent(TransactionFormComponent);
  fixture.detectChanges();
  return fixture;
}

describe('TransactionFormComponent', () => {
  beforeEach(() => localStorage.clear());
  afterEach(() => localStorage.clear());

  it('loads an existing transaction when the edit route is opened directly', () => {
    // Pre-seed storage to mimic landing on /transactions/abc/edit after a refresh.
    localStorage.setItem(STORAGE_KEY, JSON.stringify([
      { id: 'abc', description: 'Rent', amount: 15000, type: 'expense', category: 'Bills', date: '2026-02-01' }
    ]));

    const fixture = createComponent('abc');
    const host = fixture.nativeElement as HTMLElement;

    const description = host.querySelector<HTMLInputElement>('#description');
    const amount = host.querySelector<HTMLInputElement>('#amount');
    const date = host.querySelector<HTMLInputElement>('#date');

    expect(description?.value).toBe('Rent');
    expect(amount?.value).toBe('15000');
    expect(date?.value).toBe('2026-02-01');
  });

  it('swaps the category options when Income is selected', () => {
    const fixture = createComponent();
    const host = fixture.nativeElement as HTMLElement;

    const incomeRadio = host.querySelector<HTMLInputElement>('input[type="radio"][value="income"]');
    incomeRadio!.click();
    fixture.detectChanges();

    const options = Array.from(host.querySelectorAll<HTMLOptionElement>('#category option'))
      .map(option => option.textContent?.trim());

    expect(options).toContain('Salary');
    expect(options).not.toContain('Food');
  });

  it('keeps the stored category in edit mode, then clears it if the type changes', () => {
    localStorage.setItem(STORAGE_KEY, JSON.stringify([
      { id: 'inc', description: 'Bonus', amount: 1000, type: 'income', category: 'Freelance', date: '2026-03-01' }
    ]));

    const fixture = createComponent('inc');
    const host = fixture.nativeElement as HTMLElement;

    expect(host.querySelector<HTMLSelectElement>('#category')?.value).toBe('Freelance');

    // 'Freelance' is not an expense category, so switching type should clear it.
    host.querySelector<HTMLInputElement>('input[type="radio"][value="expense"]')!.click();
    fixture.detectChanges();

    expect(host.querySelector<HTMLSelectElement>('#category')?.value).toBe('');
  });
});
